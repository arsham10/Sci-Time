﻿using UnityEngine;

public class quit_button : MonoBehaviour
{
    public void Quit_Game() {
        Application.Quit(); 
    }
}
